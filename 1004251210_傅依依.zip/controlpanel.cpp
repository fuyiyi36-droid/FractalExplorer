#include "controlpanel.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QFileDialog>
#include <QMessageBox>

ControlPanel::ControlPanel(QWidget *parent) : QWidget(parent)
{
    setupUI();
}

void ControlPanel::setDrawer(FractalDrawer *drawer)
{
    m_drawer = drawer;
}

void ControlPanel::setupUI()
{
    setMinimumWidth(260);
    setMaximumWidth(300);
    auto *mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(8, 8, 8, 8);
    mainLayout->setSpacing(10);

    setStyleSheet(R"(
        QGroupBox { font-weight: bold; border: 2px solid #3a3a5c; border-radius: 6px;
                    margin-top: 12px; padding-top: 16px; color: #e0e0e0; }
        QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0 6px; color: #aaccff; }
        QLabel { color: #d0d0d0; font-size: 11pt; }
        QComboBox { background: #2a2a4a; color: #e0e0e0; border: 1px solid #555;
                     padding: 4px 8px; border-radius: 3px; min-height: 22px; }
        QComboBox::drop-down { border: none; }
        QComboBox QAbstractItemView { background: #2a2a4a; color: #e0e0e0; selection-background-color: #4a4a8a; }
        QSlider::groove:horizontal { height: 6px; background: #333; border-radius: 3px; }
        QSlider::handle:horizontal { width: 16px; height: 16px; margin: -5px 0;
                                     background: #6688cc; border-radius: 8px; }
        QPushButton { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #4a5a8a, stop:1 #2a3a5a);
                      color: #e0e0e0; border: 1px solid #556; padding: 6px 14px; border-radius: 4px;
                      min-height: 24px; font-weight: bold; }
        QPushButton:hover { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #5a6a9a, stop:1 #3a4a6a); }
        QPushButton:pressed { background: #1a2a3a; }
        QDoubleSpinBox { background: #2a2a4a; color: #e0e0e0; border: 1px solid #555;
                         padding: 3px; border-radius: 3px; }
    )");

    // ---- 分形类型 ----
    auto *typeGroup = new QGroupBox("分形类型");
    auto *typeLayout = new QVBoxLayout(typeGroup);
    m_typeCombo = new QComboBox;
    m_typeCombo->addItem("Mandelbrot 集合", 0);
    m_typeCombo->addItem("Julia 集合", 1);
    typeLayout->addWidget(m_typeCombo);
    mainLayout->addWidget(typeGroup);

    // ---- Julia 参数 ----
    m_juliaGroup = new QGroupBox("Julia 参数 K");
    auto *juliaLayout = new QFormLayout(m_juliaGroup);
    m_juliaRealSpin = new QDoubleSpinBox;
    m_juliaRealSpin->setRange(-2.0, 2.0); m_juliaRealSpin->setDecimals(5);
    m_juliaRealSpin->setSingleStep(0.01); m_juliaRealSpin->setValue(-0.7);
    juliaLayout->addRow("实部:", m_juliaRealSpin);

    m_juliaImagSpin = new QDoubleSpinBox;
    m_juliaImagSpin->setRange(-2.0, 2.0); m_juliaImagSpin->setDecimals(5);
    m_juliaImagSpin->setSingleStep(0.01); m_juliaImagSpin->setValue(0.27015);
    juliaLayout->addRow("虚部:", m_juliaImagSpin);
    mainLayout->addWidget(m_juliaGroup);

    // ---- 迭代次数 ----
    auto *iterGroup = new QGroupBox("渲染精度");
    auto *iterLayout = new QVBoxLayout(iterGroup);
    auto *iterRow = new QHBoxLayout;
    m_iterSlider = new QSlider(Qt::Horizontal);
    m_iterSlider->setRange(16, 2000);
    m_iterSlider->setValue(256);
    m_iterSlider->setTickPosition(QSlider::TicksBelow);
    m_iterSlider->setTickInterval(200);
    iterRow->addWidget(m_iterSlider);
    m_iterLabel = new QLabel("256");
    m_iterLabel->setFixedWidth(36);
    m_iterLabel->setAlignment(Qt::AlignCenter);
    iterRow->addWidget(m_iterLabel);
    iterLayout->addLayout(iterRow);
    mainLayout->addWidget(iterGroup);

    // ---- 配色方案 ----
    auto *palGroup = new QGroupBox("配色方案");
    auto *palLayout = new QVBoxLayout(palGroup);
    m_paletteCombo = new QComboBox;
    for (int i = 0; i < ColorMapper::PaletteCount; ++i)
        m_paletteCombo->addItem(ColorMapper::paletteName(static_cast<ColorMapper::Palette>(i)), i);
    palLayout->addWidget(m_paletteCombo);
    mainLayout->addWidget(palGroup);

    // ---- 操作按钮 ----
    auto *btnGroup = new QGroupBox("操作");
    auto *btnLayout = new QVBoxLayout(btnGroup);
    auto *zoomRow = new QHBoxLayout;
    m_zoomInBtn = new QPushButton("+ 放大");
    m_zoomOutBtn = new QPushButton("- 缩小");
    zoomRow->addWidget(m_zoomInBtn);
    zoomRow->addWidget(m_zoomOutBtn);
    btnLayout->addLayout(zoomRow);
    m_resetBtn = new QPushButton("重置视图");
    m_saveBtn  = new QPushButton("保存截图");
    btnLayout->addWidget(m_resetBtn);
    btnLayout->addWidget(m_saveBtn);
    mainLayout->addWidget(btnGroup);

    // ---- 状态栏 ----
    auto *statusGroup = new QGroupBox("信息");
    auto *statusLayout = new QVBoxLayout(statusGroup);
    m_coordLabel = new QLabel("中心: --\n缩放: --");
    m_coordLabel->setWordWrap(true);
    m_coordLabel->setStyleSheet("font-family: Consolas; font-size: 9pt; color: #aac;");
    statusLayout->addWidget(m_coordLabel);
    m_statusLabel = new QLabel("就绪");
    m_statusLabel->setStyleSheet("color: #8a8; font-style: italic;");
    statusLayout->addWidget(m_statusLabel);
    mainLayout->addWidget(statusGroup);

    mainLayout->addStretch();

    // ---- 信号连接 ----
    connect(m_typeCombo, static_cast<void(QComboBox::*)(int)>(&QComboBox::currentIndexChanged), this,
            [this](int idx) {
                m_juliaGroup->setVisible(idx == 1);
                emit fractalTypeChanged(m_typeCombo->itemData(m_typeCombo->currentIndex()).toInt());
            });
    connect(m_paletteCombo, static_cast<void(QComboBox::*)(int)>(&QComboBox::currentIndexChanged), this,
            [this](int) { emit paletteChanged(
                    static_cast<ColorMapper::Palette>(m_paletteCombo->currentData().toInt())); });
    connect(m_iterSlider, &QSlider::valueChanged, this, [this](int v) {
        m_iterLabel->setText(QString::number(v));
        emit iterationsChanged(v);
    });
    connect(m_juliaRealSpin, static_cast<void(QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged), this,
            [this](double) { emit juliaParamChanged(m_juliaRealSpin->value(), m_juliaImagSpin->value()); });
    connect(m_juliaImagSpin, static_cast<void(QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged), this,
            [this](double) { emit juliaParamChanged(m_juliaRealSpin->value(), m_juliaImagSpin->value()); });
    connect(m_resetBtn, &QPushButton::clicked, this, &ControlPanel::resetRequested);
    connect(m_saveBtn,  &QPushButton::clicked, this, &ControlPanel::saveRequested);
    connect(m_zoomInBtn,  &QPushButton::clicked, this, [this]() { if(m_drawer) m_drawer->zoomIn(); });
    connect(m_zoomOutBtn, &QPushButton::clicked, this, [this]() { if(m_drawer) m_drawer->zoomOut(); });
}

void ControlPanel::onViewChanged(double cx, double cy, double scale)
{
    m_coordLabel->setText(QString("中心: (%1, %2)\n缩放: %3")
                          .arg(cx, 0, 'g', 8).arg(cy, 0, 'g', 8).arg(scale, 0, 'e', 2));
}

void ControlPanel::onRenderFinished(double elapsedMs)
{
    m_statusLabel->setText(QString("渲染完成: %1 ms").arg(elapsedMs, 0, 'f', 0));
}
