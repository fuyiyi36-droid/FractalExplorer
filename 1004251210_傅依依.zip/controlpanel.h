#ifndef CONTROLPANEL_H
#define CONTROLPANEL_H

#include <QWidget>
#include <QSlider>
#include <QComboBox>
#include <QPushButton>
#include <QLabel>
#include <QDoubleSpinBox>
#include <QGroupBox>
#include "fractalengine.h"
#include "fractaldrawer.h"

class ControlPanel : public QWidget
{
    Q_OBJECT
public:
    explicit ControlPanel(QWidget *parent = nullptr);

    void setDrawer(FractalDrawer *drawer);

signals:
    void fractalTypeChanged(int type);       // 0=Mandelbrot, 1=Julia
    void paletteChanged(ColorMapper::Palette pal);
    void iterationsChanged(int n);
    void juliaParamChanged(double real, double imag);
    void saveRequested();
    void resetRequested();

public slots:
    void onViewChanged(double cx, double cy, double scale);
    void onRenderFinished(double elapsedMs);

private:
    void setupUI();

    FractalDrawer *m_drawer = nullptr;

    QComboBox    *m_typeCombo;
    QComboBox    *m_paletteCombo;
    QSlider      *m_iterSlider;
    QLabel       *m_iterLabel;
    QLabel       *m_statusLabel;
    QDoubleSpinBox *m_juliaRealSpin;
    QDoubleSpinBox *m_juliaImagSpin;
    QGroupBox    *m_juliaGroup;
    QPushButton  *m_resetBtn;
    QPushButton  *m_saveBtn;
    QPushButton  *m_zoomInBtn;
    QPushButton  *m_zoomOutBtn;
    QLabel       *m_coordLabel;
};

#endif // CONTROLPANEL_H
