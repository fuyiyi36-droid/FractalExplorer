#include <QApplication>
#include <QMainWindow>
#include <QSplitter>
#include <QMenuBar>
#include <QStatusBar>
#include <QMessageBox>
#include <QFileDialog>
#include <QAction>
#include "fractalengine.h"
#include "fractaldrawer.h"
#include "controlpanel.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    app.setApplicationName("FractalExplorer");

    // 暗色主题
    app.setStyleSheet(QStringLiteral(
        "QMainWindow { background-color: #1a1a2e; }"
        "QMenuBar { background: #12122a; color: #c0c0d0; border-bottom: 1px solid #333; }"
        "QMenuBar::item:selected { background: #334; }"
        "QMenu { background: #1e1e36; color: #d0d0d0; border: 1px solid #444; }"
        "QMenu::item:selected { background: #446; }"
        "QStatusBar { background: #12122a; color: #aaa; border-top: 1px solid #333; }"
        "QSplitter::handle { background: #333; width: 2px; }"
    ));

    // 核心组件
    FractalDrawer    *drawer     = new FractalDrawer;
    ControlPanel     *control    = new ControlPanel;
    MandelbrotEngine *mandelbrot = new MandelbrotEngine;
    JuliaEngine      *julia      = new JuliaEngine;

    control->setDrawer(drawer);
    drawer->setEngine(mandelbrot);

    // 布局: 左侧画布 + 右侧控制面板
    QSplitter *splitter = new QSplitter(Qt::Horizontal);
    splitter->addWidget(drawer);
    splitter->addWidget(control);
    splitter->setStretchFactor(0, 4);
    splitter->setStretchFactor(1, 1);

    // 主窗口
    QMainWindow mainWindow;
    mainWindow.setWindowTitle("FractalExplorer");
    mainWindow.resize(1200, 750);
    mainWindow.setCentralWidget(splitter);

    // 菜单栏
    QMenu *fileMenu = mainWindow.menuBar()->addMenu("File");
    QAction *saveAct = fileMenu->addAction("Save Screenshot...");
    QObject::connect(saveAct, &QAction::triggered, [drawer, &mainWindow]() {
        QString path = QFileDialog::getSaveFileName(&mainWindow, "Save", "fractal.png", "PNG (*.png)");
        if (!path.isEmpty()) {
            drawer->grab().save(path, "PNG");
            mainWindow.statusBar()->showMessage("Saved: " + path, 3000);
        }
    });
    fileMenu->addSeparator();
    QAction *quitAct = fileMenu->addAction("Quit");
    QObject::connect(quitAct, &QAction::triggered, &mainWindow, &QMainWindow::close);

    QMenu *viewMenu = mainWindow.menuBar()->addMenu("View");
    QAction *resetAct = viewMenu->addAction("Reset");
    QObject::connect(resetAct, &QAction::triggered, drawer, &FractalDrawer::resetView);
    QAction *zoomInAct = viewMenu->addAction("Zoom In");
    QObject::connect(zoomInAct, &QAction::triggered, drawer, &FractalDrawer::zoomIn);
    QAction *zoomOutAct = viewMenu->addAction("Zoom Out");
    QObject::connect(zoomOutAct, &QAction::triggered, drawer, &FractalDrawer::zoomOut);

    QMenu *helpMenu = mainWindow.menuBar()->addMenu("Help");
    QAction *aboutAct = helpMenu->addAction("About...");
    QObject::connect(aboutAct, &QAction::triggered, [&mainWindow]() {
        QMessageBox::about(&mainWindow, "FractalExplorer",
            "<h2>FractalExplorer v1.0</h2>"
            "<p>Mandelbrot / Julia Set Visual Explorer based on QT5.</p>"
            "<p><b>Controls:</b><br>"
            "  Drag = Pan &nbsp; | &nbsp; Wheel = Zoom<br>"
            "  Shift+Drag = Box Zoom &nbsp; | &nbsp; Right Panel = Settings</p>"
            "<p>CUGB - School of Info Engineering<br>C++ Course Project</p>");
    });

    // 状态栏
    mainWindow.statusBar()->showMessage("Ready | Drag=Pan | Wheel=Zoom | Shift+Box=Zoom");

    // 信号连接
    QObject::connect(control, &ControlPanel::fractalTypeChanged, [&](int type) {
        if (type == 1) {
            drawer->setEngine(julia);
            control->onViewChanged(julia->centerX(), julia->centerY(), julia->scale());
        } else {
            drawer->setEngine(mandelbrot);
            control->onViewChanged(mandelbrot->centerX(), mandelbrot->centerY(), mandelbrot->scale());
        }
    });

    QObject::connect(control, &ControlPanel::paletteChanged, [drawer](ColorMapper::Palette pal) {
        drawer->setColorPalette(pal);
    });

    QObject::connect(control, &ControlPanel::iterationsChanged, [drawer](int n) {
        if (FractalEngine *e = drawer->engine()) { e->setMaxIterations(n); drawer->render(); }
    });

    QObject::connect(control, &ControlPanel::juliaParamChanged, [julia, drawer](double r, double i) {
        julia->setJuliaC(r, i);
        if (drawer->engine() == julia) drawer->render();
    });

    QObject::connect(control, &ControlPanel::resetRequested, drawer, &FractalDrawer::resetView);

    QObject::connect(control, &ControlPanel::saveRequested, [drawer, &mainWindow]() {
        QString path = QFileDialog::getSaveFileName(&mainWindow, "Save", "fractal.png", "PNG (*.png)");
        if (!path.isEmpty()) drawer->grab().save(path, "PNG");
    });

    QObject::connect(drawer, &FractalDrawer::viewChanged, control, &ControlPanel::onViewChanged);
    QObject::connect(drawer, &FractalDrawer::renderFinished, control, &ControlPanel::onRenderFinished);

    mainWindow.show();
    return app.exec();
}
