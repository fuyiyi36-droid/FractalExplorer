#include "fractalengine.h"
#include <cmath>
#include <QDebug>

// ===================== FractalEngine =====================
FractalEngine::FractalEngine(QObject *parent) : QObject(parent) {}
FractalEngine::~FractalEngine() {}

// ===================== MandelbrotEngine =====================
MandelbrotEngine::MandelbrotEngine(QObject *parent) : FractalEngine(parent)
{
    m_cx = -0.5; m_cy = 0.0; m_scale = 3.0;
}

int MandelbrotEngine::computePoint(double cx, double cy, int maxIter) const
{
    double zx = 0.0, zy = 0.0;
    int iter = 0;
    // Mandelbrot: Z_{n+1} = Z_n^2 + C,  Z_0 = 0
    while (zx*zx + zy*zy <= 4.0 && iter < maxIter) {
        double tmp = zx*zx - zy*zy + cx;
        zy = 2.0 * zx * zy + cy;
        zx = tmp;
        ++iter;
    }
    return iter;
}

// ===================== JuliaEngine =====================
JuliaEngine::JuliaEngine(QObject *parent) : FractalEngine(parent)
{
    m_cx = 0.0; m_cy = 0.0; m_scale = 3.0;
}

int JuliaEngine::computePoint(double cx, double cy, int maxIter) const
{
    double zx = cx, zy = cy;
    int iter = 0;
    // Julia: Z_{n+1} = Z_n^2 + K,  Z_0 = C (当前像素坐标), K = (m_jr, m_ji) 固定
    while (zx*zx + zy*zy <= 4.0 && iter < maxIter) {
        double tmp = zx*zx - zy*zy + m_jr;
        zy = 2.0 * zx * zy + m_ji;
        zx = tmp;
        ++iter;
    }
    return iter;
}

// ===================== ColorMapper =====================
QColor ColorMapper::map(int iter, int maxIter, Palette pal)
{
    if (iter >= maxIter)
        return QColor(0, 0, 0);  // 集合内部 = 黑色

    double t = static_cast<double>(iter) / maxIter;

    // 平滑着色：使用 log 平滑技术减少色带
    // t = t; // 后续可加 smooth = iter - log2(log2(|z|))

    int r = 0, g = 0, b = 0;

    switch (pal) {
    case Rainbow: {
        // HSL → RGB: 色相从红→紫循环
        double h = fmod(t * 360.0 * 5.0, 360.0);
        double s = 1.0, l = 0.5;
        auto hue2rgb = [](double p, double q, double t_h) {
            if (t_h < 0) t_h += 1; if (t_h > 1) t_h -= 1;
            if (t_h < 1.0/6) return p + (q-p)*6*t_h;
            if (t_h < 1.0/2) return q;
            if (t_h < 2.0/3) return p + (q-p)*(2.0/3 - t_h)*6;
            return p;
        };
        double q = l < 0.5 ? l*(1+s) : l+s-l*s;
        double p = 2*l - q;
        double hk = h / 360.0;
        r = static_cast<int>(hue2rgb(p, q, hk + 1.0/3) * 255);
        g = static_cast<int>(hue2rgb(p, q, hk) * 255);
        b = static_cast<int>(hue2rgb(p, q, hk - 1.0/3) * 255);
        break;
    }
    case Fire:
        r = static_cast<int>(255 * (t < 0.5 ? t*2 : 1.0));
        g = static_cast<int>(255 * (t < 0.5 ? 0 : (t-0.5)*2));
        b = static_cast<int>(255 * (t < 0.25 ? 0 : (t-0.25)*0.5));
        break;

    case Ocean:
        r = static_cast<int>(255 * t * 0.3);
        g = static_cast<int>(255 * (0.3 + t * 0.5));
        b = static_cast<int>(255 * (0.5 + t * 0.5));
        break;

    case Grayscale:
        r = g = b = static_cast<int>(255 * t);
        break;

    case Cosmic: {
        // 深紫→蓝→青→白
        r = static_cast<int>(255 * t * t * 1.5);
        g = static_cast<int>(255 * t * 0.6);
        b = static_cast<int>(255 * (0.3 + t * 0.7));
        if (r > 255) r = 255; if (g > 255) g = 255; if (b > 255) b = 255;
        break;
    }
    case Lava: {
        r = static_cast<int>(255 * (0.5 + 0.5 * sin(t * 8)));
        g = static_cast<int>(80 * t + 30 * (1-t));
        b = static_cast<int>(60 * (1 - t));
        if (r < 0) r = 0; if (r > 255) r = 255;
        if (g < 0) g = 0; if (g > 255) g = 255;
        if (b < 0) b = 0; if (b > 255) b = 255;
        break;
    }
    default: break;
    }

    return QColor(r, g, b);
}

QString ColorMapper::paletteName(Palette pal)
{
    switch (pal) {
    case Rainbow:   return "彩虹";
    case Fire:      return "火焰";
    case Ocean:     return "海洋";
    case Grayscale: return "灰度";
    case Cosmic:    return "星空";
    case Lava:      return "熔岩";
    default:        return "未知";
    }
}
