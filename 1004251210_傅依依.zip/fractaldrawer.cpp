#include "fractaldrawer.h"
#include <QPainter>
#include <QMouseEvent>
#include <QWheelEvent>
#include <QElapsedTimer>
#include <QDebug>
#include <QApplication>

FractalDrawer::FractalDrawer(QWidget *parent)
    : QWidget(parent)
{
    setMouseTracking(true);
    setMinimumSize(400, 300);
    setFocusPolicy(Qt::WheelFocus);
    setCursor(Qt::CrossCursor);
}

void FractalDrawer::setEngine(FractalEngine *engine)
{
    m_engine = engine;
    m_needRender = true;
    update();
}

void FractalDrawer::resetView()
{
    if (m_engine) {
        m_engine->setCenter(-0.5, 0.0);
        m_engine->setScale(3.0);
        m_needRender = true;
        update();
        emit viewChanged(m_engine->centerX(), m_engine->centerY(), m_engine->scale());
    }
}

void FractalDrawer::zoomIn()
{
    if (m_engine) {
        double newScale = m_engine->scale() / 2.0;
        if (newScale < 1e-15) newScale = 1e-15;
        m_engine->setScale(newScale);
        m_needRender = true; update();
        emit viewChanged(m_engine->centerX(), m_engine->centerY(), m_engine->scale());
    }
}

void FractalDrawer::zoomOut()
{
    if (m_engine) {
        m_engine->setScale(m_engine->scale() * 2.0);
        m_needRender = true; update();
        emit viewChanged(m_engine->centerX(), m_engine->centerY(), m_engine->scale());
    }
}

void FractalDrawer::render()
{
    if (!m_engine || !m_needRender) return;
    if (m_rendering) return;  // 防止重入
    m_rendering = true;

    emit renderStarted();
    QElapsedTimer timer;
    timer.start();

    int w = width(), h = height();
    if (w <= 0 || h <= 0) { m_rendering = false; return; }

    m_image = QImage(w, h, QImage::Format_RGB32);
    renderToImage(m_image, w, h);

    m_needRender = false;
    m_rendering = false;
    emit renderFinished(timer.elapsed());
}

void FractalDrawer::renderToImage(QImage &img, int w, int h)
{
    if (!m_engine) return;

    const double cx = m_engine->centerX();
    const double cy = m_engine->centerY();
    const double scale = m_engine->scale();
    const int maxIter = m_engine->maxIterations();

    const double aspect = static_cast<double>(w) / h;
    const double halfH = scale / 2.0;
    const double halfW = halfH * aspect;

    // 逐像素计算（可后续用 QThread 并行化）
    for (int py = 0; py < h; ++py) {
        uchar *line = img.scanLine(py);
        for (int px = 0; px < w; ++px) {
            // 像素坐标 → 复平面坐标
            double re = cx + (static_cast<double>(px) / w - 0.5) * 2.0 * halfW;
            double im = cy + (0.5 - static_cast<double>(py) / h) * 2.0 * halfH;

            int iter = m_engine->computePoint(re, im, maxIter);
            QColor c = ColorMapper::map(iter, maxIter, m_palette);
            line[px * 4 + 2] = c.red();
            line[px * 4 + 1] = c.green();
            line[px * 4 + 0] = c.blue();
        }
    }
}

// ==================== 事件处理 ====================
void FractalDrawer::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);

    // 渲染模式（首次或参数变更后）
    if (m_needRender)
        const_cast<FractalDrawer*>(this)->render();

    // 绘制分形图像
    if (!m_image.isNull())
        painter.drawImage(0, 0, m_image);
    else {
        painter.fillRect(rect(), QColor(20, 20, 40));
        painter.setPen(Qt::white);
        painter.setFont(QFont("Microsoft YaHei", 14));
        painter.drawText(rect(), Qt::AlignCenter, "准备就绪 - 请选择分形类型");
    }

    // 绘制框选矩形
    if (m_boxSelecting) {
        painter.setPen(QPen(QColor(255, 255, 0, 180), 1, Qt::DashLine));
        painter.setBrush(QColor(255, 255, 0, 30));
        QRect r = QRect(m_boxStart, m_boxEnd).normalized();
        painter.drawRect(r);
    }

    // 绘制当前坐标信息
    painter.setPen(QColor(255, 255, 255, 200));
    painter.setFont(QFont("Consolas", 9));
    if (m_engine) {
        painter.fillRect(5, 5, 380, 18, QColor(0, 0, 0, 120));
        painter.drawText(10, 18, QString("中心: (%1, %2)  |  缩放: %3  |  迭代: %4")
                         .arg(m_engine->centerX(), 0, 'g', 8)
                         .arg(m_engine->centerY(), 0, 'g', 8)
                         .arg(m_engine->scale(), 0, 'e', 1)
                         .arg(m_engine->maxIterations()));
    }
}

void FractalDrawer::mousePressEvent(QMouseEvent *e)
{
    if (e->button() == Qt::LeftButton) {
        if (e->modifiers() & Qt::ShiftModifier) {
            // Shift+左键 = 框选放大
            m_boxSelecting = true;
            m_boxStart = e->pos();
            m_boxEnd = e->pos();
        } else {
            // 普通左键 = 拖拽
            m_dragging = true;
            m_lastMousePos = e->pos();
            setCursor(Qt::ClosedHandCursor);
        }
    }
}

void FractalDrawer::mouseMoveEvent(QMouseEvent *e)
{
    if (m_dragging) {
        QPoint delta = e->pos() - m_lastMousePos;
        m_lastMousePos = e->pos();
        if (m_engine) {
            double scale = m_engine->scale();
            double aspect = static_cast<double>(width()) / height();
            double dx = -delta.x() * scale * aspect / width();
            double dy = delta.y() * scale / height();
            m_engine->setCenter(m_engine->centerX() + dx, m_engine->centerY() + dy);
            m_needRender = true;
            update();
            emit viewChanged(m_engine->centerX(), m_engine->centerY(), scale);
        }
    }
    if (m_boxSelecting) {
        m_boxEnd = e->pos();
        update();
    }
}

void FractalDrawer::mouseReleaseEvent(QMouseEvent *e)
{
    if (e->button() == Qt::LeftButton && m_dragging) {
        m_dragging = false;
        setCursor(Qt::CrossCursor);
    }
    if (e->button() == Qt::LeftButton && m_boxSelecting) {
        m_boxSelecting = false;
        // 框选完成 → 放大到框选区域
        QRect r = QRect(m_boxStart, m_boxEnd).normalized();
        if (r.width() > 10 && r.height() > 10 && m_engine) {
            double aspect = static_cast<double>(width()) / height();
            double oldScale = m_engine->scale();
            double oldHalfW = oldScale * aspect / 2.0;
            double oldHalfH = oldScale / 2.0;

            double cx = m_engine->centerX();
            double cy = m_engine->centerY();

            double newCx = cx + ((r.center().x() / static_cast<double>(width()))  - 0.5) * 2.0 * oldHalfW;
            double newCy = cy + (0.5 - (r.center().y() / static_cast<double>(height()))) * 2.0 * oldHalfH;
            double newScale = oldScale * std::max(
                static_cast<double>(r.width()) / width(),
                static_cast<double>(r.height()) / height());

            m_engine->setCenter(newCx, newCy);
            m_engine->setScale(newScale);
            m_needRender = true;
            update();
            emit viewChanged(newCx, newCy, newScale);
        }
    }
}

void FractalDrawer::wheelEvent(QWheelEvent *e)
{
    if (!m_engine) return;
    double factor = (e->angleDelta().y() > 0) ? 0.7 : 1.4;

    // 以鼠标位置为中心缩放
    double aspect = static_cast<double>(width()) / height();
    double oldScale = m_engine->scale();
    double newScale = oldScale * factor;
    if (newScale < 1e-15) newScale = 1e-15;

    double mx = static_cast<double>(e->pos().x()) / width();
    double my = static_cast<double>(e->pos().y()) / height();

    double oldHalfW = oldScale * aspect / 2.0;
    double oldHalfH = oldScale / 2.0;
    double newHalfW = newScale * aspect / 2.0;
    double newHalfH = newScale / 2.0;

    double cx = m_engine->centerX();
    double cy = m_engine->centerY();

    double px = cx + (mx - 0.5) * 2.0 * oldHalfW;
    double py = cy + (0.5 - my) * 2.0 * oldHalfH;
    double newCx = px - (mx - 0.5) * 2.0 * newHalfW;
    double newCy = py - (0.5 - my) * 2.0 * newHalfH;

    m_engine->setCenter(newCx, newCy);
    m_engine->setScale(newScale);
    m_needRender = true;
    update();
    emit viewChanged(newCx, newCy, newScale);
}

void FractalDrawer::resizeEvent(QResizeEvent *)
{
    m_needRender = true;
}

double FractalDrawer::viewCenterX() const { return m_engine ? m_engine->centerX() : 0; }
double FractalDrawer::viewCenterY() const { return m_engine ? m_engine->centerY() : 0; }
double FractalDrawer::viewScale() const    { return m_engine ? m_engine->scale() : 0; }
int    FractalDrawer::maxIterations() const { return m_engine ? m_engine->maxIterations() : 0; }
