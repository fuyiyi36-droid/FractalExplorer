/****************************************************************************
** Meta object code from reading C++ file 'fractaldrawer.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.2.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fractaldrawer.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'fractaldrawer.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.2.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_FractalDrawer_t {
    QByteArrayData data[9];
    char stringdata[79];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_FractalDrawer_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_FractalDrawer_t qt_meta_stringdata_FractalDrawer = {
    {
QT_MOC_LITERAL(0, 0, 13),
QT_MOC_LITERAL(1, 14, 13),
QT_MOC_LITERAL(2, 28, 0),
QT_MOC_LITERAL(3, 29, 14),
QT_MOC_LITERAL(4, 44, 9),
QT_MOC_LITERAL(5, 54, 11),
QT_MOC_LITERAL(6, 66, 2),
QT_MOC_LITERAL(7, 69, 2),
QT_MOC_LITERAL(8, 72, 5)
    },
    "FractalDrawer\0renderStarted\0\0"
    "renderFinished\0elapsedMs\0viewChanged\0"
    "cx\0cy\0scale\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_FractalDrawer[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   29,    2, 0x06,
       3,    1,   30,    2, 0x06,
       5,    3,   33,    2, 0x06,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Double,    4,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Double,    6,    7,    8,

       0        // eod
};

void FractalDrawer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        FractalDrawer *_t = static_cast<FractalDrawer *>(_o);
        switch (_id) {
        case 0: _t->renderStarted(); break;
        case 1: _t->renderFinished((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 2: _t->viewChanged((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (FractalDrawer::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&FractalDrawer::renderStarted)) {
                *result = 0;
            }
        }
        {
            typedef void (FractalDrawer::*_t)(double );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&FractalDrawer::renderFinished)) {
                *result = 1;
            }
        }
        {
            typedef void (FractalDrawer::*_t)(double , double , double );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&FractalDrawer::viewChanged)) {
                *result = 2;
            }
        }
    }
}

const QMetaObject FractalDrawer::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_FractalDrawer.data,
      qt_meta_data_FractalDrawer,  qt_static_metacall, 0, 0}
};


const QMetaObject *FractalDrawer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FractalDrawer::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_FractalDrawer.stringdata))
        return static_cast<void*>(const_cast< FractalDrawer*>(this));
    return QWidget::qt_metacast(_clname);
}

int FractalDrawer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 3)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 3;
    }
    return _id;
}

// SIGNAL 0
void FractalDrawer::renderStarted()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void FractalDrawer::renderFinished(double _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void FractalDrawer::viewChanged(double _t1, double _t2, double _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_END_MOC_NAMESPACE
