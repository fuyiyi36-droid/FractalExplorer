#ifndef FRACTALENGINE_H
#define FRACTALENGINE_H

#include <QObject>
#include <QImage>
#include <QColor>
#include <complex>
#include <vector>

// ================================================================
// 抽象基类：分形引擎 —— 多态核心
// ================================================================
class FractalEngine : public QObject
{
    Q_OBJECT
public:
    explicit FractalEngine(QObject *parent = nullptr);
    virtual ~FractalEngine();

    // 纯虚函数：计算给定点的逃逸迭代次数
    virtual int computePoint(double cx, double cy, int maxIter) const = 0;
    // 虚函数：返回分形类型名称
    virtual QString fractalName() const = 0;

    // 公共属性
    void setMaxIterations(int n) { m_maxIter = n; }
    int  maxIterations() const { return m_maxIter; }
    void setCenter(double x, double y) { m_cx = x; m_cy = y; }
    double centerX() const { return m_cx; }
    double centerY() const { return m_cy; }
    void setScale(double s) { m_scale = s; }
    double scale() const { return m_scale; }

protected:
    int    m_maxIter = 256;
    double m_cx = -0.5, m_cy = 0.0;
    double m_scale = 3.0;
};

// ================================================================
// 派生类：Mandelbrot 集合
// ================================================================
class MandelbrotEngine : public FractalEngine
{
    Q_OBJECT
public:
    explicit MandelbrotEngine(QObject *parent = nullptr);
    int computePoint(double cx, double cy, int maxIter) const override;
    QString fractalName() const override { return "Mandelbrot 集合"; }
};

// ================================================================
// 派生类：Julia 集合
// ================================================================
class JuliaEngine : public FractalEngine
{
    Q_OBJECT
public:
    explicit JuliaEngine(QObject *parent = nullptr);
    int computePoint(double cx, double cy, int maxIter) const override;
    QString fractalName() const override { return "Julia 集合"; }

    void setJuliaC(double real, double imag) { m_jr = real; m_ji = imag; }
    double juliaReal() const { return m_jr; }
    double juliaImag() const { return m_ji; }

private:
    double m_jr = -0.7, m_ji = 0.27015;  // 经典 Julia 参数
};

// ================================================================
// 颜色映射器 —— 将迭代次数映射为炫彩颜色
// ================================================================
class ColorMapper
{
public:
    enum Palette { Rainbow, Fire, Ocean, Grayscale, Cosmic, Lava, PaletteCount };
    static QColor map(int iter, int maxIter, Palette pal);
    static QString paletteName(Palette pal);
};

#endif // FRACTALENGINE_H
