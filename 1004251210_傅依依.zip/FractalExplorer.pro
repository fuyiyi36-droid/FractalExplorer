QT       += core gui widgets
TEMPLATE = app
CONFIG  += c++11
TARGET   = FractalExplorer

SOURCES += main.cpp \
    fractalengine.cpp \
    fractaldrawer.cpp \
    controlpanel.cpp

HEADERS += \
    fractalengine.h \
    fractaldrawer.h \
    controlpanel.h
