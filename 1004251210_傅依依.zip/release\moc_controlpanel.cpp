/****************************************************************************
** Meta object code from reading C++ file 'controlpanel.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.2.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../controlpanel.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'controlpanel.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.2.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_ControlPanel_t {
    QByteArrayData data[20];
    char stringdata[209];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_ControlPanel_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_ControlPanel_t qt_meta_stringdata_ControlPanel = {
    {
QT_MOC_LITERAL(0, 0, 12),
QT_MOC_LITERAL(1, 13, 18),
QT_MOC_LITERAL(2, 32, 0),
QT_MOC_LITERAL(3, 33, 4),
QT_MOC_LITERAL(4, 38, 14),
QT_MOC_LITERAL(5, 53, 20),
QT_MOC_LITERAL(6, 74, 3),
QT_MOC_LITERAL(7, 78, 17),
QT_MOC_LITERAL(8, 96, 1),
QT_MOC_LITERAL(9, 98, 17),
QT_MOC_LITERAL(10, 116, 4),
QT_MOC_LITERAL(11, 121, 4),
QT_MOC_LITERAL(12, 126, 13),
QT_MOC_LITERAL(13, 140, 14),
QT_MOC_LITERAL(14, 155, 13),
QT_MOC_LITERAL(15, 169, 2),
QT_MOC_LITERAL(16, 172, 2),
QT_MOC_LITERAL(17, 175, 5),
QT_MOC_LITERAL(18, 181, 16),
QT_MOC_LITERAL(19, 198, 9)
    },
    "ControlPanel\0fractalTypeChanged\0\0type\0"
    "paletteChanged\0ColorMapper::Palette\0"
    "pal\0iterationsChanged\0n\0juliaParamChanged\0"
    "real\0imag\0saveRequested\0resetRequested\0"
    "onViewChanged\0cx\0cy\0scale\0onRenderFinished\0"
    "elapsedMs\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ControlPanel[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   54,    2, 0x06,
       4,    1,   57,    2, 0x06,
       7,    1,   60,    2, 0x06,
       9,    2,   63,    2, 0x06,
      12,    0,   68,    2, 0x06,
      13,    0,   69,    2, 0x06,

 // slots: name, argc, parameters, tag, flags
      14,    3,   70,    2, 0x0a,
      18,    1,   77,    2, 0x0a,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, 0x80000000 | 5,    6,
    QMetaType::Void, QMetaType::Int,    8,
    QMetaType::Void, QMetaType::Double, QMetaType::Double,   10,   11,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Double,   15,   16,   17,
    QMetaType::Void, QMetaType::Double,   19,

       0        // eod
};

void ControlPanel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ControlPanel *_t = static_cast<ControlPanel *>(_o);
        switch (_id) {
        case 0: _t->fractalTypeChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->paletteChanged((*reinterpret_cast< ColorMapper::Palette(*)>(_a[1]))); break;
        case 2: _t->iterationsChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->juliaParamChanged((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 4: _t->saveRequested(); break;
        case 5: _t->resetRequested(); break;
        case 6: _t->onViewChanged((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3]))); break;
        case 7: _t->onRenderFinished((*reinterpret_cast< double(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (ControlPanel::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ControlPanel::fractalTypeChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (ControlPanel::*_t)(ColorMapper::Palette );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ControlPanel::paletteChanged)) {
                *result = 1;
            }
        }
        {
            typedef void (ControlPanel::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ControlPanel::iterationsChanged)) {
                *result = 2;
            }
        }
        {
            typedef void (ControlPanel::*_t)(double , double );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ControlPanel::juliaParamChanged)) {
                *result = 3;
            }
        }
        {
            typedef void (ControlPanel::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ControlPanel::saveRequested)) {
                *result = 4;
            }
        }
        {
            typedef void (ControlPanel::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ControlPanel::resetRequested)) {
                *result = 5;
            }
        }
    }
}

const QMetaObject ControlPanel::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_ControlPanel.data,
      qt_meta_data_ControlPanel,  qt_static_metacall, 0, 0}
};


const QMetaObject *ControlPanel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ControlPanel::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ControlPanel.stringdata))
        return static_cast<void*>(const_cast< ControlPanel*>(this));
    return QWidget::qt_metacast(_clname);
}

int ControlPanel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void ControlPanel::fractalTypeChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void ControlPanel::paletteChanged(ColorMapper::Palette _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void ControlPanel::iterationsChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void ControlPanel::juliaParamChanged(double _t1, double _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void ControlPanel::saveRequested()
{
    QMetaObject::activate(this, &staticMetaObject, 4, 0);
}

// SIGNAL 5
void ControlPanel::resetRequested()
{
    QMetaObject::activate(this, &staticMetaObject, 5, 0);
}
QT_END_MOC_NAMESPACE
