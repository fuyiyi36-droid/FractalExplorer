#ifndef FRACTALDRAWER_H
#define FRACTALDRAWER_H

#include <QWidget>
#include <QImage>
#include <QPoint>
#include <QThread>
#include "fractalengine.h"

class FractalDrawer : public QWidget
{
    Q_OBJECT
public:
    explicit FractalDrawer(QWidget *parent = nullptr);

    FractalEngine* engine() const { return m_engine; }
    void setEngine(FractalEngine *engine);
    void setColorPalette(ColorMapper::Palette pal) { m_palette = pal; update(); }

    void render();            // 渲染分形图像
    void resetView();         // 重置视图
    void zoomIn();            // 放大
    void zoomOut();           // 缩小

    double viewCenterX() const;
    double viewCenterY() const;
    double viewScale() const;
    int    maxIterations() const;

signals:
    void renderStarted();
    void renderFinished(double elapsedMs);
    void viewChanged(double cx, double cy, double scale);

protected:
    void paintEvent(QPaintEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;
    void wheelEvent(QWheelEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;

private:
    void renderToImage(QImage &img, int w, int h);

    FractalEngine *m_engine   = nullptr;
    ColorMapper::Palette m_palette = ColorMapper::Rainbow;
    QImage  m_image;

    // 交互状态
    bool    m_dragging = false;
    QPoint  m_lastMousePos;
    QPoint  m_boxStart, m_boxEnd;
    bool    m_boxSelecting = false;

    // 渲染状态
    bool    m_rendering = false;
    bool    m_needRender = true;
};

#endif // FRACTALDRAWER_H
